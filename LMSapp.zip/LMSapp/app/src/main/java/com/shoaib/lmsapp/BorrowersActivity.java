package com.shoaib.lmsapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class BorrowersActivity extends AppCompatActivity {

    // UI Components
    private TextInputEditText userIdEditText, nameEditText, addressEditText, cityEditText,
            stateEditText, zipCodeEditText, passwordEditText;
    private MaterialButton addButton, updateButton, deleteButton;
    private RecyclerView borrowersRecyclerView;
    private MaterialToolbar topAppBar;

    // Adapter for RecyclerView
    private BorrowerAdapter borrowerAdapter;

    // Data list for borrowers
    private List<Borrower> borrowerList;

    // Database helper
    private BorrowerDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrowers);

        // Initialize database helper
        dbHelper = new BorrowerDatabaseHelper(this);

        // Initialize UI components
        initializeViews();

        // Set up the toolbar with back button
        setupToolbar();

        // Set up RecyclerView
        setupRecyclerView();

        // Set up button click listeners
        setupButtonListeners();

        // Load borrowers from database
        loadBorrowers();
    }

    private void initializeViews() {
        // EditTexts
        userIdEditText = findViewById(R.id.userIdEditText);
        nameEditText = findViewById(R.id.nameEditText);
        addressEditText = findViewById(R.id.addressEditText);
        cityEditText = findViewById(R.id.cityEditText);
        stateEditText = findViewById(R.id.stateEditText);
        zipCodeEditText = findViewById(R.id.zipCodeEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Buttons
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        // RecyclerView
        borrowersRecyclerView = findViewById(R.id.borrowersRecyclerView);

        // Toolbar
        topAppBar = findViewById(R.id.topAppBar);
    }

    private void setupToolbar() {
        // Set the toolbar as the action bar
        setSupportActionBar(topAppBar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Set navigation click listener (back button)
        topAppBar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the back button click
                onBackPressed();
            }
        });
    }

    private void setupRecyclerView() {
        borrowerList = new ArrayList<>();
        borrowerAdapter = new BorrowerAdapter(borrowerList);

        // Set layout manager
        borrowersRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set adapter
        borrowersRecyclerView.setAdapter(borrowerAdapter);

        // Set item click listener
        borrowerAdapter.setOnItemClickListener(new BorrowerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Borrower borrower) {
                // Fill the form with selected borrower data
                populateFormWithBorrower(borrower);
            }
        });
    }

    private void setupButtonListeners() {
        // Add button click listener
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBorrower();
            }
        });

        // Update button click listener
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateBorrower();
            }
        });

        // Delete button click listener
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteBorrower();
            }
        });
    }

    private void loadBorrowers() {
        // Clear existing data
        borrowerList.clear();

        // Get borrowers from database
        List<Borrower> loadedBorrowers = dbHelper.getAllBorrowers();

        // Add to the list
        borrowerList.addAll(loadedBorrowers);

        // Notify adapter
        borrowerAdapter.notifyDataSetChanged();
    }

    private void addBorrower() {
        // Get values from form
        String userId = userIdEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();
        String city = cityEditText.getText().toString().trim();
        String state = stateEditText.getText().toString().trim();
        String zipCode = zipCodeEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input
        if (userId.isEmpty() || name.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "User ID, Name and Password are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create borrower object
        Borrower borrower = new Borrower();
        borrower.setUserId(userId);
        borrower.setName(name);
        borrower.setAddress(address);
        borrower.setCity(city);
        borrower.setState(state);
        borrower.setZipCode(zipCode);
        borrower.setPassword(password);

        // Add to database
        long result = dbHelper.addBorrower(borrower);

        if (result > 0) {
            Toast.makeText(this, "Borrower added successfully", Toast.LENGTH_SHORT).show();
            clearForm();
            loadBorrowers(); // Refresh list
        } else {
            Toast.makeText(this, "Failed to add borrower", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateBorrower() {
        // Get values from form
        String userId = userIdEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String address = addressEditText.getText().toString().trim();
        String city = cityEditText.getText().toString().trim();
        String state = stateEditText.getText().toString().trim();
        String zipCode = zipCodeEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input
        if (userId.isEmpty()) {
            Toast.makeText(this, "Please select a borrower to update", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create borrower object
        Borrower borrower = new Borrower();
        borrower.setUserId(userId);
        borrower.setName(name);
        borrower.setAddress(address);
        borrower.setCity(city);
        borrower.setState(state);
        borrower.setZipCode(zipCode);
        borrower.setPassword(password);

        // Update in database
        int result = dbHelper.updateBorrower(borrower);

        if (result > 0) {
            Toast.makeText(this, "Borrower updated successfully", Toast.LENGTH_SHORT).show();
            clearForm();
            loadBorrowers(); // Refresh list
        } else {
            Toast.makeText(this, "Failed to update borrower", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteBorrower() {
        // Get user ID from form
        String userId = userIdEditText.getText().toString().trim();

        // Validate input
        if (userId.isEmpty()) {
            Toast.makeText(this, "Please select a borrower to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        // Delete from database
        int result = dbHelper.deleteBorrower(userId);

        if (result > 0) {
            Toast.makeText(this, "Borrower deleted successfully", Toast.LENGTH_SHORT).show();
            clearForm();
            loadBorrowers(); // Refresh list
        } else {
            Toast.makeText(this, "Failed to delete borrower", Toast.LENGTH_SHORT).show();
        }
    }

    private void populateFormWithBorrower(Borrower borrower) {
        userIdEditText.setText(borrower.getUserId());
        nameEditText.setText(borrower.getName());
        addressEditText.setText(borrower.getAddress());
        cityEditText.setText(borrower.getCity());
        stateEditText.setText(borrower.getState());
        zipCodeEditText.setText(borrower.getZipCode());
        passwordEditText.setText(borrower.getPassword());
    }

    private void clearForm() {
        userIdEditText.setText("");
        nameEditText.setText("");
        addressEditText.setText("");
        cityEditText.setText("");
        stateEditText.setText("");
        zipCodeEditText.setText("");
        passwordEditText.setText("");

        // Give focus to user ID field
        userIdEditText.requestFocus();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // This method is called when the back button is pressed
        // You can add custom behavior here if needed
        finish();
    }
}