package com.shoaib.lmsapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class BorrowerLoginActivity extends AppCompatActivity {

    private TextInputLayout emailInputLayout;
    private TextInputEditText emailInput;
    private TextInputLayout passwordInputLayout;
    private TextInputEditText passwordInput;
    private Button loginButton;
    private TextView forgotPasswordTextView;
    private TextView registerLinkTextView;
    private BorrowerDatabaseHelper dbHelper;
    private View backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrower_login);

        // Initialize the database helper
        dbHelper = new BorrowerDatabaseHelper(this);

        // Initialize UI components
        initializeViews();

        // Set up listeners
        setupListeners();
    }

    private void initializeViews() {
        emailInputLayout = findViewById(R.id.email_input_layout);
        emailInput = findViewById(R.id.email_input);
        passwordInputLayout = findViewById(R.id.password_input_layout);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        forgotPasswordTextView = findViewById(R.id.forgot_password);
        registerLinkTextView = findViewById(R.id.register_link);
        backButton = findViewById(R.id.back_button);
        // Set click listener for back button
        backButton.setOnClickListener(v -> onBackPressed());

        // Set click listener for login button
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void setupListeners() {
        // Login button click listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptLogin();
            }
        });

        // Forgot password click listener
        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(BorrowerLoginActivity.this, "Forgot password feature coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        // Register link click listener
        registerLinkTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(BorrowerLoginActivity.this, "Please Request!To Admin and Register It.", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void attemptLogin() {
        // Reset errors
        emailInputLayout.setError(null);
        passwordInputLayout.setError(null);

        // Get values from input fields
        String userId = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password
        if (TextUtils.isEmpty(password)) {
            passwordInputLayout.setError(getString(R.string.error_field_required));
            focusView = passwordInput;
            cancel = true;
        }

        // Check for a valid user ID/email
        if (TextUtils.isEmpty(userId)) {
            emailInputLayout.setError(getString(R.string.error_field_required));
            focusView = emailInput;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first form field with an error
            focusView.requestFocus();
        } else {
            // Show a progress spinner and perform the user login attempt
            performLogin(userId, password);
        }
    }

    private void performLogin(String userId, String password) {
        // Query the database for the user
        Borrower borrower = dbHelper.getBorrower(userId);

        if (borrower != null && password.equals(borrower.getPassword())) {
            // Display welcome message with user's name
            Toast.makeText(this, "Welcome, " + borrower.getName() + "!", Toast.LENGTH_SHORT).show();

            // Store login state in SharedPreferences
            saveLoginSession(borrower);

            // Navigate to main activity instead of borrower dashboard
            Intent intent = new Intent(BorrowerLoginActivity.this, BorrowerPortalActivity.class);
            intent.putExtra("USER_ID", borrower.getUserId());
            intent.putExtra("USER_NAME", borrower.getName());
            startActivity(intent);
            finish(); // Close login activity
        } else {
            // Failed login
            Toast.makeText(this, "Invalid user ID or password", Toast.LENGTH_SHORT).show();
            passwordInput.setText("");
        }
    }

    private void saveLoginSession(Borrower borrower) {
        // Create or get shared preferences
        android.content.SharedPreferences preferences = getSharedPreferences("LMS_PREFS", MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = preferences.edit();

        // Save login state and user info
        editor.putBoolean("IS_LOGGED_IN", true);
        editor.putString("USER_ID", borrower.getUserId());
        editor.putString("USER_NAME", borrower.getName());

        // Apply changes
        editor.apply();
    }
}