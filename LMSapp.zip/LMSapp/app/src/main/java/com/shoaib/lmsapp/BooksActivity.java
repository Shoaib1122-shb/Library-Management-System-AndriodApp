package com.shoaib.lmsapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BooksActivity extends AppCompatActivity implements BookAdapter.OnBookClickListener {

    private EditText isbnEditText, nameEditText, authorEditText, totalNumberEditText, borrowerNumberEditText;
    private Button addButton, updateButton, deleteButton;
    private RecyclerView booksRecyclerView;
    private BookAdapter bookAdapter;
    private BookDatabaseHelper dbHelper;
    private List<Book> bookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);

        // Setup Toolbar with Back Button
        Toolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Library Management System");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        isbnEditText = findViewById(R.id.isbnEditText);
        nameEditText = findViewById(R.id.nameEditText);
        authorEditText = findViewById(R.id.authorEditText);
        totalNumberEditText = findViewById(R.id.totalNumberEditText);
        borrowerNumberEditText = findViewById(R.id.borrowerNumberEditText);
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);
        booksRecyclerView = findViewById(R.id.booksRecyclerView);

        dbHelper = new BookDatabaseHelper(this);
        booksRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadBooks();

        addButton.setOnClickListener(v -> addBook());
        updateButton.setOnClickListener(v -> updateBook());
        deleteButton.setOnClickListener(v -> deleteBook());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Finish this activity when back button in toolbar is pressed
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadBooks() {
        bookList = dbHelper.getAllBooks();
        bookAdapter = new BookAdapter(bookList, this);
        booksRecyclerView.setAdapter(bookAdapter);
    }

    private void addBook() {
        String isbn = isbnEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String author = authorEditText.getText().toString().trim();
        String totalNumberStr = totalNumberEditText.getText().toString().trim();
        String borrowerNumberStr = borrowerNumberEditText.getText().toString().trim();

        if (TextUtils.isEmpty(isbn) || TextUtils.isEmpty(name) || TextUtils.isEmpty(author) ||
                TextUtils.isEmpty(totalNumberStr) || TextUtils.isEmpty(borrowerNumberStr)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int totalNumber = Integer.parseInt(totalNumberStr);
        int borrowerNumber = Integer.parseInt(borrowerNumberStr);

        if (borrowerNumber > totalNumber) {
            Toast.makeText(this, "Borrower number cannot exceed total number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.getBook(isbn) != null) {
            Toast.makeText(this, "Book with this ISBN already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        Book newBook = new Book(isbn, name, author, totalNumber, borrowerNumber);
        long result = dbHelper.addBook(newBook);

        if (result != -1) {
            Toast.makeText(this, "Book added successfully", Toast.LENGTH_SHORT).show();
            clearFields();
            loadBooks();
        } else {
            Toast.makeText(this, "Failed to add book", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateBook() {
        String isbn = isbnEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String author = authorEditText.getText().toString().trim();
        String totalNumberStr = totalNumberEditText.getText().toString().trim();
        String borrowerNumberStr = borrowerNumberEditText.getText().toString().trim();

        if (TextUtils.isEmpty(isbn)) {
            Toast.makeText(this, "Please enter ISBN to update", Toast.LENGTH_SHORT).show();
            return;
        }

        Book existingBook = dbHelper.getBook(isbn);
        if (existingBook == null) {
            Toast.makeText(this, "Book with this ISBN does not exist", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!TextUtils.isEmpty(name)) existingBook.setName(name);
        if (!TextUtils.isEmpty(author)) existingBook.setAuthor(author);
        if (!TextUtils.isEmpty(totalNumberStr)) existingBook.setTotalNumber(Integer.parseInt(totalNumberStr));
        if (!TextUtils.isEmpty(borrowerNumberStr)) existingBook.setBorrowerNumber(Integer.parseInt(borrowerNumberStr));

        if (existingBook.getBorrowerNumber() > existingBook.getTotalNumber()) {
            Toast.makeText(this, "Borrower number cannot exceed total number", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = dbHelper.updateBook(existingBook);
        if (result > 0) {
            Toast.makeText(this, "Book updated successfully", Toast.LENGTH_SHORT).show();
            clearFields();
            loadBooks();
        } else {
            Toast.makeText(this, "Failed to update book", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteBook() {
        String isbn = isbnEditText.getText().toString().trim();

        if (TextUtils.isEmpty(isbn)) {
            Toast.makeText(this, "Please enter ISBN to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        Book existingBook = dbHelper.getBook(isbn);
        if (existingBook == null) {
            Toast.makeText(this, "Book with this ISBN does not exist", Toast.LENGTH_SHORT).show();
            return;
        }

        dbHelper.deleteBook(isbn);
        Toast.makeText(this, "Book deleted successfully", Toast.LENGTH_SHORT).show();
        clearFields();
        loadBooks();
    }

    private void clearFields() {
        isbnEditText.setText("");
        nameEditText.setText("");
        authorEditText.setText("");
        totalNumberEditText.setText("");
        borrowerNumberEditText.setText("");
        isbnEditText.requestFocus();
    }

    @Override
    public void onBookClick(int position) {
        Book selectedBook = bookList.get(position);
        isbnEditText.setText(selectedBook.getIsbn());
        nameEditText.setText(selectedBook.getName());
        authorEditText.setText(selectedBook.getAuthor());
        totalNumberEditText.setText(String.valueOf(selectedBook.getTotalNumber()));
        borrowerNumberEditText.setText(String.valueOf(selectedBook.getBorrowerNumber()));
    }
}
