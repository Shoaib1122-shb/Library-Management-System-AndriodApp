package com.shoaib.lmsapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class BorrowerAdapter extends RecyclerView.Adapter<BorrowerAdapter.BorrowerViewHolder> {

    // List to hold borrower data
    private List<Borrower> borrowerList;

    // Listener for item clicks
    private OnItemClickListener onItemClickListener;

    // Constructor
    public BorrowerAdapter(List<Borrower> borrowerList) {
        this.borrowerList = borrowerList;
    }

    // Interface for item click listener
    public interface OnItemClickListener {
        void onItemClick(Borrower borrower);
    }

    // Setter for the click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    @NonNull
    @Override
    public BorrowerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_borrower, parent, false);
        return new BorrowerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BorrowerViewHolder holder, int position) {
        // Get the borrower at the current position
        Borrower borrower = borrowerList.get(position);

        // Bind data to the views
        holder.userIdTextView.setText(borrower.getUserId());
        holder.nameTextView.setText(borrower.getName());
        holder.addressTextView.setText(borrower.getAddress());

        // Set click listener for the item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(borrower);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return borrowerList.size();
    }

    // ViewHolder class
    public static class BorrowerViewHolder extends RecyclerView.ViewHolder {
        TextView userIdTextView, nameTextView, addressTextView;

        public BorrowerViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize the TextViews from the item layout
            userIdTextView = itemView.findViewById(R.id.itemUserId);
            nameTextView = itemView.findViewById(R.id.itemName);
            addressTextView = itemView.findViewById(R.id.itemAddress);
        }
    }
}