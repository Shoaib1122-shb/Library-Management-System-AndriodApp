package com.shoaib.lmsapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ReserveBookDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "library.db";
    private static final int DATABASE_VERSION = 1;

    // Reservation table
    private static final String TABLE_RESERVATIONS = "reservations";
    private static final String COLUMN_RESERVATION_ID = "reservation_id";
    private static final String COLUMN_BOOK_ISBN = "book_isbn";
    private static final String COLUMN_BORROWER_ID = "borrower_id";
    private static final String COLUMN_RESERVATION_DATE = "reservation_date";
    private static final String COLUMN_EXPIRY_DATE = "expiry_date";
    private static final String COLUMN_STATUS = "status";

    public ReserveBookDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_RESERVATIONS_TABLE = "CREATE TABLE " + TABLE_RESERVATIONS + "("
                + COLUMN_RESERVATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_BOOK_ISBN + " TEXT,"
                + COLUMN_BORROWER_ID + " INTEGER,"
                + COLUMN_RESERVATION_DATE + " TEXT,"
                + COLUMN_EXPIRY_DATE + " TEXT,"
                + COLUMN_STATUS + " TEXT DEFAULT 'PENDING')";
        db.execSQL(CREATE_RESERVATIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        onCreate(db);
    }

    public boolean addReservation(String bookIsbn, int borrowerId, String reservationDate, String expiryDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BOOK_ISBN, bookIsbn);
        values.put(COLUMN_BORROWER_ID, borrowerId);
        values.put(COLUMN_RESERVATION_DATE, reservationDate);
        values.put(COLUMN_EXPIRY_DATE, expiryDate);

        long result = db.insert(TABLE_RESERVATIONS, null, values);
        db.close();
        return result != -1;
    }
}