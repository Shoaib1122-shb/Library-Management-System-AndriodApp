package com.shoaib.lmsapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BorrowBookActivity extends AppCompatActivity {
    private static final String TAG = "BorrowBookActivity";
    private BookDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrow_book);

        dbHelper = new BookDatabaseHelper(this);

        TextView titleTextView = findViewById(R.id.book_title);
        TextView authorTextView = findViewById(R.id.book_author);
        Button confirmButton = findViewById(R.id.confirm_borrow_button);

        String isbn = getIntent().getStringExtra("BOOK_ISBN");
        String title = getIntent().getStringExtra("BOOK_TITLE");
        String author = getIntent().getStringExtra("BOOK_AUTHOR");

        Log.d(TAG, "Received ISBN: " + isbn + ", Title: " + title + ", Author: " + author);

        titleTextView.setText(title);
        authorTextView.setText(author);

        confirmButton.setOnClickListener(v -> {
            Log.d(TAG, "Confirm borrow button clicked for ISBN: " + isbn);
            int borrowerId = getCurrentBorrowerId();
            long borrowDate = System.currentTimeMillis();
            long dueDate = borrowDate + 14L * 24 * 60 * 60 * 1000; // 14 days


        });
    }

    private int getCurrentBorrowerId() {
        // TODO: Replace with actual authentication system implementation
        return 1;
    }
}