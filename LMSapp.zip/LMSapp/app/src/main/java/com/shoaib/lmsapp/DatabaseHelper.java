package com.shoaib.lmsapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Borrow_reaerve_books_Library.DB";
    private static final int DATABASE_VERSION = 1;
    private static final String TAG = "DatabaseHelper";

    // Borrowed Books Table
    private static final String TABLE_BORROWED_BOOKS = "borrowed_books";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_BORROWER_ID = "borrower_id";
    private static final String COLUMN_ISBN = "isbn";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_AUTHOR = "author";
    private static final String COLUMN_BORROW_DATE = "borrow_date";
    private static final String COLUMN_DUE_DATE = "due_date";

    // Reserved Books Table
    private static final String TABLE_RESERVED_BOOKS = "reserved_books";
    private static final String COLUMN_RESERVE_ID = "reserve_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createBorrowedBooksTable = "CREATE TABLE " + TABLE_BORROWED_BOOKS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_BORROWER_ID + " TEXT, " +
                COLUMN_ISBN + " TEXT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_AUTHOR + " TEXT, " +
                COLUMN_BORROW_DATE + " TEXT, " +
                COLUMN_DUE_DATE + " TEXT)";

        String createReservedBooksTable = "CREATE TABLE " + TABLE_RESERVED_BOOKS + " (" +
                COLUMN_RESERVE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_BORROWER_ID + " TEXT, " +
                COLUMN_ISBN + " TEXT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_AUTHOR + " TEXT, " +
                COLUMN_BORROW_DATE + " TEXT)";

        db.execSQL(createBorrowedBooksTable);
        db.execSQL(createReservedBooksTable);
        Log.d(TAG, "Database tables created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BORROWED_BOOKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVED_BOOKS);
        onCreate(db);
        Log.d(TAG, "Database upgraded from version " + oldVersion + " to " + newVersion);
    }

    // CRUD Operations for Borrowed Books
    public long addBorrowedBook(BorrowedBook book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BORROWER_ID, book.getBorrowerId());
        values.put(COLUMN_ISBN, book.getIsbn());
        values.put(COLUMN_TITLE, book.getTitle());
        values.put(COLUMN_AUTHOR, book.getAuthor());
        values.put(COLUMN_BORROW_DATE, book.getBorrowDate());
        values.put(COLUMN_DUE_DATE, book.getDueDate());

        long result = db.insert(TABLE_BORROWED_BOOKS, null, values);
        Log.d(TAG, "Add borrowed book result: " + result);
        db.close();
        return result;
    }

    public List<BorrowedBook> getAllBorrowedBooks() {
        List<BorrowedBook> books = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_BORROWED_BOOKS, null);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    BorrowedBook book = new BorrowedBook(
                            cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BORROWER_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISBN)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BORROW_DATE)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DUE_DATE))
                    );
                    books.add(book);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error retrieving borrowed books: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        Log.d(TAG, "Retrieved " + books.size() + " borrowed books");
        return books;
    }

    public boolean updateBorrowedBook(BorrowedBook book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BORROWER_ID, book.getBorrowerId());
        values.put(COLUMN_ISBN, book.getIsbn());
        values.put(COLUMN_TITLE, book.getTitle());
        values.put(COLUMN_AUTHOR, book.getAuthor());
        values.put(COLUMN_BORROW_DATE, book.getBorrowDate());
        values.put(COLUMN_DUE_DATE, book.getDueDate());

        int rows = db.update(TABLE_BORROWED_BOOKS, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(book.getId())});
        db.close();
        Log.d(TAG, "Update borrowed book, rows affected: " + rows);
        return rows > 0;
    }

    public boolean deleteBorrowedBook(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_BORROWED_BOOKS, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        Log.d(TAG, "Delete borrowed book, rows affected: " + rows);
        return rows > 0;
    }

    // CRUD Operations for Reserved Books
    public long addReservedBook(ReservedBook book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BORROWER_ID, book.getBorrowerId());
        values.put(COLUMN_ISBN, book.getIsbn());
        values.put(COLUMN_TITLE, book.getTitle());
        values.put(COLUMN_AUTHOR, book.getAuthor());
        values.put(COLUMN_BORROW_DATE, book.getBorrowDate());

        long result = db.insert(TABLE_RESERVED_BOOKS, null, values);
        Log.d(TAG, "Add reserved book result: " + result);
        db.close();
        return result;
    }

    public List<ReservedBook> getAllReservedBooks() {
        List<ReservedBook> books = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_RESERVED_BOOKS, null);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    ReservedBook book = new ReservedBook(
                            cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_RESERVE_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BORROWER_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISBN)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BORROW_DATE))
                    );
                    books.add(book);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error retrieving reserved books: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        Log.d(TAG, "Retrieved " + books.size() + " reserved books");
        return books;
    }

    public boolean deleteReservedBook(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_RESERVED_BOOKS, COLUMN_RESERVE_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        Log.d(TAG, "Delete reserved book, rows affected: " + rows);
        return rows > 0;
    }
}