package com.shoaib.lmsapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

public class LibrarianActivity extends AppCompatActivity implements LibrarianAdapter.OnLibrarianClickListener {

    private TextInputEditText staffIdEditText, nameEditText, emailEditText, phoneEditText, positionEditText, passwordEditText;
    private Button addButton, updateButton, deleteButton;
    private RecyclerView librariansRecyclerView;
    private LibrarianAdapter librarianAdapter;
    private LibrarianDatabaseHelper dbHelper;
    private List<Librarian> librarianList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian);

        // Setup Toolbar with Back Button
        Toolbar toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Library Management System");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Initialize UI components
        staffIdEditText = findViewById(R.id.staffId);
        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        positionEditText = findViewById(R.id.positionEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        librariansRecyclerView = findViewById(R.id.librariansRecyclerView);

        // Initialize database helper
        dbHelper = new LibrarianDatabaseHelper(this);

        // Set up RecyclerView
        librariansRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadLibrarians();

        // Set up button click listeners
        addButton.setOnClickListener(v -> addLibrarian());
        updateButton.setOnClickListener(v -> updateLibrarian());
        deleteButton.setOnClickListener(v -> deleteLibrarian());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            // Finish this activity when back button in toolbar is pressed
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadLibrarians() {
        librarianList = dbHelper.getAllLibrarians();
        librarianAdapter = new LibrarianAdapter(librarianList, this, this);
        librariansRecyclerView.setAdapter(librarianAdapter);
    }

    private void addLibrarian() {
        String staffId = staffIdEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String position = positionEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(staffId) || TextUtils.isEmpty(name) || TextUtils.isEmpty(email) ||
                TextUtils.isEmpty(phone) || TextUtils.isEmpty(position) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.getLibrarianById(staffId) != null) {
            Toast.makeText(this, "Staff ID already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        Librarian newLibrarian = new Librarian(staffId, name, email, phone, position, password);
        long result = dbHelper.addLibrarian(newLibrarian);

        if (result != -1) {
            Toast.makeText(this, "Librarian added successfully", Toast.LENGTH_SHORT).show();
            clearFields();
            loadLibrarians();
        } else {
            Toast.makeText(this, "Failed to add librarian", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateLibrarian() {
        String staffId = staffIdEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String position = positionEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(staffId)) {
            Toast.makeText(this, "Please enter Staff ID to update", Toast.LENGTH_SHORT).show();
            return;
        }

        Librarian existingLibrarian = dbHelper.getLibrarianById(staffId);
        if (existingLibrarian == null) {
            Toast.makeText(this, "Librarian with this Staff ID does not exist", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!TextUtils.isEmpty(name)) existingLibrarian.setName(name);
        if (!TextUtils.isEmpty(email)) existingLibrarian.setEmail(email);
        if (!TextUtils.isEmpty(phone)) existingLibrarian.setPhone(phone);
        if (!TextUtils.isEmpty(position)) existingLibrarian.setPosition(position);
        if (!TextUtils.isEmpty(password)) existingLibrarian.setPassword(password);

        int result = dbHelper.updateLibrarian(existingLibrarian);
        if (result > 0) {
            Toast.makeText(this, "Librarian updated successfully", Toast.LENGTH_SHORT).show();
            clearFields();
            loadLibrarians();
        } else {
            Toast.makeText(this, "Failed to update librarian", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteLibrarian() {
        String staffId = staffIdEditText.getText().toString().trim();

        if (TextUtils.isEmpty(staffId)) {
            Toast.makeText(this, "Please enter Staff ID to delete", Toast.LENGTH_SHORT).show();
            return;
        }

        Librarian existingLibrarian = dbHelper.getLibrarianById(staffId);
        if (existingLibrarian == null) {
            Toast.makeText(this, "Librarian with this Staff ID does not exist", Toast.LENGTH_SHORT).show();
            return;
        }

        int result = dbHelper.deleteLibrarian(staffId);
        if (result > 0) {
            Toast.makeText(this, "Librarian deleted successfully", Toast.LENGTH_SHORT).show();
            clearFields();
            loadLibrarians();
        } else {
            Toast.makeText(this, "Failed to delete librarian", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        staffIdEditText.setText("");
        nameEditText.setText("");
        emailEditText.setText("");
        phoneEditText.setText("");
        positionEditText.setText("");
        passwordEditText.setText("");
        staffIdEditText.requestFocus();
    }

    @Override
    public void onLibrarianClick(Librarian librarian) {
        staffIdEditText.setText(librarian.getStaffId());
        nameEditText.setText(librarian.getName());
        emailEditText.setText(librarian.getEmail());
        phoneEditText.setText(librarian.getPhone());
        positionEditText.setText(librarian.getPosition());
        passwordEditText.setText(librarian.getPassword());
    }
}