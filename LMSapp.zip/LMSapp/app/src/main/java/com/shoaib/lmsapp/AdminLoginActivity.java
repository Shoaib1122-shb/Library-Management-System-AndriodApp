package com.shoaib.lmsapp;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class AdminLoginActivity extends AppCompatActivity {

    private TextInputEditText emailInput, passwordInput;
    private MaterialButton loginButton;
    private View backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        // Initialize views
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        backButton = findViewById(R.id.back_button);

        // Set click listener for back button
        backButton.setOnClickListener(v -> onBackPressed());

        // Set click listener for login button
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Basic validation
        if (email.isEmpty()) {
            emailInput.setError("Email is required");
            emailInput.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            passwordInput.setError("Password is required");
            passwordInput.requestFocus();
            return;
        }

        // Check if it's admin credentials (in a real app, this would be server-side verification)
        if (isValidAdminCredentials(email, password)) {
            // Login successful
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

            // Start Admin Dashboard Activity
            Intent intent = new Intent(this, AdminPortalActivity.class);
            startActivity(intent);
            finish();
        } else {
            // Login failed
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidAdminCredentials(String email, String password) {

        String adminEmail = "shoaib@lms.com";
        String adminPassword = "shoaib123";

        return email.equals(adminEmail) && password.equals(adminPassword);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // Optional: Add transition animation
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}