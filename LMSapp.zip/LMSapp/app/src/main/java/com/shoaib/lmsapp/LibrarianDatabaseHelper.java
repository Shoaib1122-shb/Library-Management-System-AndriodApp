package com.shoaib.lmsapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class LibrarianDatabaseHelper extends SQLiteOpenHelper {
    // Database information
    private static final String DATABASE_NAME = "library_management.db";
    private static final int DATABASE_VERSION = 1;

    // Table name
    private static final String TABLE_LIBRARIANS = "librarians";

    // Column names
    private static final String COLUMN_STAFF_ID = "staff_id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PHONE = "phone";
    private static final String COLUMN_POSITION = "position";
    private static final String COLUMN_PASSWORD = "password";

    // Create table query
    private static final String CREATE_LIBRARIANS_TABLE = "CREATE TABLE " + TABLE_LIBRARIANS + " (" +
            COLUMN_STAFF_ID + " TEXT PRIMARY KEY, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_EMAIL + " TEXT, " +
            COLUMN_PHONE + " TEXT, " +
            COLUMN_POSITION + " TEXT, " +
            COLUMN_PASSWORD + " TEXT)";

    public LibrarianDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_LIBRARIANS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LIBRARIANS);
        onCreate(db);
    }

    // CRUD Operations

    // Create (Add) a new librarian
    public long addLibrarian(Librarian librarian) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_STAFF_ID, librarian.getStaffId());
        values.put(COLUMN_NAME, librarian.getName());
        values.put(COLUMN_EMAIL, librarian.getEmail());
        values.put(COLUMN_PHONE, librarian.getPhone());
        values.put(COLUMN_POSITION, librarian.getPosition());
        values.put(COLUMN_PASSWORD, librarian.getPassword());

        // Insert row
        long id = db.insert(TABLE_LIBRARIANS, null, values);
        db.close();

        return id;
    }

    // Read (Get) a librarian by ID
    public Librarian getLibrarianById(String staffId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_LIBRARIANS,
                new String[]{COLUMN_STAFF_ID, COLUMN_NAME, COLUMN_EMAIL, COLUMN_PHONE, COLUMN_POSITION, COLUMN_PASSWORD},
                COLUMN_STAFF_ID + "=?",
                new String[]{staffId},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Librarian librarian = new Librarian(
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STAFF_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_POSITION)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD))
            );

            cursor.close();
            return librarian;
        }

        if (cursor != null) {
            cursor.close();
        }

        return null;
    }

    // Read (Get) all librarians
    public List<Librarian> getAllLibrarians() {
        List<Librarian> librarianList = new ArrayList<>();

        // Select all query
        String selectQuery = "SELECT * FROM " + TABLE_LIBRARIANS;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // Loop through all rows and add to list
        if (cursor.moveToFirst()) {
            do {
                Librarian librarian = new Librarian(
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STAFF_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_POSITION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD))
                );

                librarianList.add(librarian);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return librarianList;
    }

    // Update a librarian
    public int updateLibrarian(Librarian librarian) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_NAME, librarian.getName());
        values.put(COLUMN_EMAIL, librarian.getEmail());
        values.put(COLUMN_PHONE, librarian.getPhone());
        values.put(COLUMN_POSITION, librarian.getPosition());
        values.put(COLUMN_PASSWORD, librarian.getPassword());

        // Update row
        int result = db.update(TABLE_LIBRARIANS, values, COLUMN_STAFF_ID + " = ?",
                new String[]{librarian.getStaffId()});

        db.close();
        return result;
    }

    // Delete a librarian
    public int deleteLibrarian(String staffId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_LIBRARIANS, COLUMN_STAFF_ID + " = ?",
                new String[]{staffId});

        db.close();
        return result;
    }

    public Librarian getLibrarianByStaffId(String staffId) {
        return null;
    }

    public long getBooksCount() {
        return 0;
    }

    public long getBorrowersCount() {
        return 0;
    }
}