package com.shoaib.lmsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LibrarianAdapter extends RecyclerView.Adapter<LibrarianAdapter.LibrarianViewHolder> {

    private List<Librarian> librarianList;
    private Context context;
    private OnLibrarianClickListener listener;

    public interface OnLibrarianClickListener {
        void onLibrarianClick(Librarian librarian);
    }

    public LibrarianAdapter(List<Librarian> librarianList, Context context, OnLibrarianClickListener listener) {
        this.librarianList = librarianList;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public LibrarianViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_librarian, parent, false);
        return new LibrarianViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LibrarianViewHolder holder, int position) {
        Librarian librarian = librarianList.get(position);

        holder.staffIdTextView.setText("ID: " + librarian.getStaffId());
        holder.nameTextView.setText(librarian.getName());
        holder.emailTextView.setText(librarian.getEmail());
        holder.phoneTextView.setText(librarian.getPhone());
        holder.positionTextView.setText(librarian.getPosition());

        holder.librarianCard.setOnClickListener(v -> {
            if (listener != null) {
                listener.onLibrarianClick(librarian);
            }
        });
    }

    @Override
    public int getItemCount() {
        return librarianList.size();
    }

    static class LibrarianViewHolder extends RecyclerView.ViewHolder {
        CardView librarianCard;
        TextView staffIdTextView, nameTextView, emailTextView, phoneTextView, positionTextView;

        public LibrarianViewHolder(@NonNull View itemView) {
            super(itemView);
            librarianCard = itemView.findViewById(R.id.librarianCard);
            staffIdTextView = itemView.findViewById(R.id.staffIdTextView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            emailTextView = itemView.findViewById(R.id.emailTextView);
            phoneTextView = itemView.findViewById(R.id.phoneTextView);
            positionTextView = itemView.findViewById(R.id.positionTextView);
        }
    }
}