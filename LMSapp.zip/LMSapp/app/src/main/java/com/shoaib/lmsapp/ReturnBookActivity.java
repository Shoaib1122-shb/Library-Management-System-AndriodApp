package com.shoaib.lmsapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import java.util.List;

public class ReturnBookActivity extends AppCompatActivity {

    private static final String TAG = "ReturnBookActivity";
    private RecyclerView recyclerViewBorrowed, recyclerViewReserved;
    private DatabaseHelper dbHelper;
    private BorrowedBooksAdapter borrowedBooksAdapter;
    private ReservedBooksAdapter reservedBooksAdapter;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_return_book);

        // Set up window insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();
        setupToolbar();
        dbHelper = new DatabaseHelper(this);
        setupRecyclerViews();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        recyclerViewBorrowed = findViewById(R.id.recyclerViewBorrowed);
        recyclerViewReserved = findViewById(R.id.recyclerViewReserved);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        // The title is set in the layout with a custom view, so we don't need to set it here
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupRecyclerViews() {
        recyclerViewBorrowed.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewReserved.setLayoutManager(new LinearLayoutManager(this));

        List<BorrowedBook> borrowedBooks = dbHelper.getAllBorrowedBooks();
        List<ReservedBook> reservedBooks = dbHelper.getAllReservedBooks();

        borrowedBooksAdapter = new BorrowedBooksAdapter(borrowedBooks, this::editBorrowedBook, this::returnBorrowedBook);
        reservedBooksAdapter = new ReservedBooksAdapter(reservedBooks, this::cancelReservedBook);

        recyclerViewBorrowed.setAdapter(borrowedBooksAdapter);
        recyclerViewReserved.setAdapter(reservedBooksAdapter);
        Log.d(TAG, "RecyclerViews set up with " + borrowedBooks.size() + " borrowed books and " + reservedBooks.size() + " reserved books");
    }

    private void editBorrowedBook(BorrowedBook book, View view) {
        Toast.makeText(this, "GO TO ADMIN OR LIBRARIAN FOR UPDATED", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "Edit clicked for book with ID: " + book.getId());
    }

    private void returnBorrowedBook(BorrowedBook book, View view) {
        Log.d(TAG, "Attempting to return book with ID: " + book.getId());
        boolean result = dbHelper.deleteBorrowedBook(book.getId());
        if (result) {
            borrowedBooksAdapter.removeBook(book);
            Toast.makeText(this, "Book returned successfully", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Book returned successfully with ID: " + book.getId());
        } else {
            Toast.makeText(this, "Failed to return book", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Failed to return book with ID: " + book.getId());
        }
    }

    private void cancelReservedBook(ReservedBook book, View view) {
        Log.d(TAG, "Attempting to cancel reserved book with ID: " + "book.getId()");
        boolean result = dbHelper.deleteReservedBook(book.getId());
        if (result) {
            reservedBooksAdapter.removeBook(book);
            Toast.makeText(this, "Reservation canceled successfully", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Reservation canceled successfully with ID: " + book.getId());
        } else {
            Toast.makeText(this, "Failed to cancel reservation", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Failed to cancel reservation with ID: " + book.getId());
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}