package com.shoaib.lmsapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<Book> bookList;
    private OnBookClickListener listener;


    public BookAdapter(ViewBooksActivity viewBooksActivity, List<Book> bookList, BookDatabaseHelper dbHelper, int borrowerId) {
        this.bookList = bookList;
        this.listener = viewBooksActivity;
    }

    public void updateList(List<Book> filteredList) {
        bookList = filteredList;
        notifyDataSetChanged();
    }
    public interface OnBookClickListener {
        void onBookClick(int position); // Called when a card is clicked
    }

    public BookAdapter(List<Book> bookList, OnBookClickListener listener) {
        this.bookList = bookList;
        this.listener = listener;
    }

    @Override
    public BookViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_item, parent, false);
        return new BookViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(BookViewHolder holder, int position) {
        Book book = bookList.get(position);
        holder.isbnTextView.setText("ISBN: " + book.getIsbn());
        holder.nameTextView.setText(book.getName());
        holder.authorTextView.setText(book.getAuthor());
        holder.totalNumberTextView.setText("Total: " + book.getTotalNumber());
        holder.borrowerNumberTextView.setText("Borrowed: " + book.getBorrowerNumber());

        // You can implement click actions here if needed
        holder.editButton.setOnClickListener(v -> {
            if (listener != null && position != RecyclerView.NO_POSITION) {
                listener.onBookClick(position); // Use to pre-fill form for editing
            }
        });

        holder.deleteButton.setOnClickListener(v -> {
            if (listener != null && position != RecyclerView.NO_POSITION) {
                // Optional: define a second listener method for delete
                listener.onBookClick(position); // Reuse or extend this as needed
            }
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView isbnTextView, nameTextView, authorTextView, totalNumberTextView, borrowerNumberTextView;
        MaterialButton editButton, deleteButton;

        public BookViewHolder(View itemView, OnBookClickListener listener) {
            super(itemView);
            isbnTextView = itemView.findViewById(R.id.item_isbn);
            nameTextView = itemView.findViewById(R.id.item_name);
            authorTextView = itemView.findViewById(R.id.item_author);
            totalNumberTextView = itemView.findViewById(R.id.item_total_number);
            borrowerNumberTextView = itemView.findViewById(R.id.item_borrower_number);
            editButton = itemView.findViewById(R.id.item_edit_button);
            deleteButton = itemView.findViewById(R.id.item_delete_button);

            // Optional: handle full item click
            itemView.setOnClickListener(v -> {
                if (listener != null && getAdapterPosition() != RecyclerView.NO_POSITION) {
                    listener.onBookClick(getAdapterPosition());
                }
            });
        }
    }
}
