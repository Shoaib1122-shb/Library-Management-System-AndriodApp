package com.shoaib.lmsapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LibrarianLoginActivity extends AppCompatActivity {

    private TextInputEditText emailInput, passwordInput;
    private MaterialButton loginButton;
    private LibrarianDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian_login);

        // Initialize views
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);

        // Initialize database helper
        dbHelper = new LibrarianDatabaseHelper(this);

        // Back button click listener
        findViewById(R.id.back_button).setOnClickListener(v -> finish());

        // Login button click listener
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        // Reset errors
        emailInput.setError(null);
        passwordInput.setError(null);

        // Get input values
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Validate inputs
        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(email)) {
            emailInput.setError("Email is required");
            focusView = emailInput;
            cancel = true;
        } else if (!isEmailValid(email)) {
            emailInput.setError("Invalid email address");
            focusView = emailInput;
            cancel = true;
        }

        if (TextUtils.isEmpty(password)) {
            passwordInput.setError("Password is required");
            focusView = passwordInput;
            cancel = true;
        }

        if (cancel) {
            // Focus on the first field with an error
            focusView.requestFocus();
            return;
        }

        // Verify credentials
        Librarian librarian = verifyCredentials(email, password);
        if (librarian != null) {
            // Successful login, navigate to Librarian Portal
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LibrarianPortalActivity.class);
            intent.putExtra("staff_id", librarian.getStaffId()); // Pass staff ID to portal
            startActivity(intent);
            finish(); // Close login activity
        } else {
            // Failed login
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
            passwordInput.setError("Invalid credentials");
            passwordInput.requestFocus();
        }
    }

    private boolean isEmailValid(String email) {
        // Basic email validation
        return email.contains("@") && email.contains(".");
    }

    private Librarian verifyCredentials(String email, String password) {
        // Query all librarians and check for matching email and password
        for (Librarian librarian : dbHelper.getAllLibrarians()) {
            if (librarian.getEmail().equals(email) && librarian.getPassword().equals(password)) {
                return librarian;
            }
        }
        return null;
    }
}