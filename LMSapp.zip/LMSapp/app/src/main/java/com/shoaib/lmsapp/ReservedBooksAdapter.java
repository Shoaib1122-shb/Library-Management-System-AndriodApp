package com.shoaib.lmsapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.function.BiConsumer;

public class ReservedBooksAdapter extends RecyclerView.Adapter<ReservedBooksAdapter.ViewHolder> {
    private static final String TAG = "ReservedBooksAdapter";
    private List<ReservedBook> books;
    private BiConsumer<ReservedBook, View> onDeleteClick;

    public ReservedBooksAdapter(List<ReservedBook> books, BiConsumer<ReservedBook, View> onDeleteClick) {
        this.books = books;
        this.onDeleteClick = onDeleteClick;
        Log.d(TAG, "Adapter initialized with " + books.size() + " books");
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reserved_book, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReservedBook book = books.get(position);
        Log.d(TAG, "Binding reserved book at position " + position + ": ID=" + book.getId() + ", Title=" + book.getTitle());
        holder.tvId.setText(String.valueOf(book.getId()));
        holder.tvTitle.setText(book.getTitle());
        holder.tvAuthor.setText(book.getAuthor());
        holder.tvIsbn.setText(book.getIsbn());
        holder.tvReserveDate.setText(book.getBorrowDate());

        holder.btnDelete.setOnClickListener(v -> {
            Log.d(TAG, "Delete clicked for reserved book ID: " + book.getId());
            onDeleteClick.accept(book, v);
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public void addBook(ReservedBook book) {
        books.add(book);
        notifyItemInserted(books.size() - 1);
        Log.d(TAG, "Added reserved book with ID: " + book.getId() + ", Total books: " + books.size());
    }

    public void removeBook(ReservedBook book) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId() == book.getId()) {
                books.remove(i);
                notifyItemRemoved(i);
                Log.d(TAG, "Removed reserved book with ID: " + book.getId() + ", Total books: " + books.size());
                break;
            }
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvId, tvTitle, tvAuthor, tvIsbn, tvReserveDate;
        ImageButton btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvId);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvAuthor = itemView.findViewById(R.id.tvAuthor);
            tvIsbn = itemView.findViewById(R.id.tvIsbn);
            tvReserveDate = itemView.findViewById(R.id.tvReserveDate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}