package com.shoaib.lmsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons directly (safer than parent traversal)
        View adminButton = findViewById(R.id.adminButton);
        View librarianButton = findViewById(R.id.librarianButton);
        View memberButton = findViewById(R.id.memberButton);

        // Get parent cards if needed for animation
        CardView adminCard = (CardView) adminButton.getParent().getParent();
        CardView librarianCard = (CardView) librarianButton.getParent().getParent();
        CardView borrowerCard = (CardView) memberButton.getParent().getParent();

        // Load animations safely with null checks
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        if (fadeIn != null) {
            adminCard.startAnimation(fadeIn);
            librarianCard.startAnimation(fadeIn);
            borrowerCard.startAnimation(fadeIn);

            // Stagger animations
            if (librarianCard.getAnimation() != null) {
                librarianCard.getAnimation().setStartOffset(200);
            }
            if (borrowerCard.getAnimation() != null) {
                borrowerCard.getAnimation().setStartOffset(400);
            }
        }


        if (adminButton != null) {
            adminButton.setOnClickListener(v -> {
                animateButtonClick(v);
                startActivity(new Intent(MainActivity.this, AdminLoginActivity.class));
            });
        }

        if (librarianButton != null) {
            librarianButton.setOnClickListener(v -> {
                animateButtonClick(v);
                startActivity(new Intent(MainActivity.this, LibrarianLoginActivity.class));
            });
        }

        if (memberButton != null) {
            memberButton.setOnClickListener(v -> {
                animateButtonClick(v);
                startActivity(new Intent(MainActivity.this, BorrowerLoginActivity.class));
            });
        }
    }

    private void animateButtonClick(View view) {
        if (view != null) {
            Animation scaleDown = AnimationUtils.loadAnimation(this, R.anim.scale_down);
            if (scaleDown != null) {
                view.startAnimation(scaleDown);
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}