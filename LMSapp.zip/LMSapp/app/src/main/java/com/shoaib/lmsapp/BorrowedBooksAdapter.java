package com.shoaib.lmsapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.function.BiConsumer;

public class BorrowedBooksAdapter extends RecyclerView.Adapter<BorrowedBooksAdapter.ViewHolder> {
    private static final String TAG = "BorrowedBooksAdapter";
    private List<BorrowedBook> books;
    private BiConsumer<BorrowedBook, View> onEditClick;
    private BiConsumer<BorrowedBook, View> onDeleteClick;

    public BorrowedBooksAdapter(List<BorrowedBook> books, BiConsumer<BorrowedBook, View> onEditClick,
                                BiConsumer<BorrowedBook, View> onDeleteClick) {
        this.books = books;
        this.onEditClick = onEditClick;
        this.onDeleteClick = onDeleteClick;
        Log.d(TAG, "Adapter initialized with " + books.size() + " books");
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_borrowed_book, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BorrowedBook book = books.get(position);
        Log.d(TAG, "Binding book at position " + position + ": ID=" + book.getId() + ", Title=" + book.getTitle());
        holder.tvId.setText(String.valueOf(book.getId()));
        holder.tvTitle.setText(book.getTitle());
        holder.tvAuthor.setText(book.getAuthor());
        holder.tvIsbn.setText(book.getIsbn());
        holder.tvBorrowDate.setText(book.getBorrowDate());
        holder.tvDueDate.setText(book.getDueDate());

        holder.btnEdit.setOnClickListener(v -> {
            Log.d(TAG, "Edit clicked for book ID: " + book.getId());
            onEditClick.accept(book, v);
        });
        holder.btnDelete.setOnClickListener(v -> {
            Log.d(TAG, "Delete clicked for book ID: " + book.getId());
            onDeleteClick.accept(book, v);
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public void addBook(BorrowedBook book) {
        books.add(book);
        notifyItemInserted(books.size() - 1);
        Log.d(TAG, "Added book with ID: " + book.getId() + ", Total books: " + books.size());
    }

    public void updateBook(BorrowedBook updatedBook) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId() == updatedBook.getId()) {
                books.set(i, updatedBook);
                notifyItemChanged(i);
                Log.d(TAG, "Updated book with ID: " + updatedBook.getId());
                break;
            }
        }
    }

    public void removeBook(BorrowedBook book) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId() == book.getId()) {
                books.remove(i);
                notifyItemRemoved(i);
                Log.d(TAG, "Removed book with ID: " + book.getId() + ", Total books: " + books.size());
                break;
            }
        }
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvId, tvTitle, tvAuthor, tvIsbn, tvBorrowDate, tvDueDate;
        ImageButton btnEdit, btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvId);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvAuthor = itemView.findViewById(R.id.tvAuthor);
            tvIsbn = itemView.findViewById(R.id.tvIsbn);
            tvBorrowDate = itemView.findViewById(R.id.tvBorrowDate);
            tvDueDate = itemView.findViewById(R.id.tvDueDate);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}