package com.shoaib.lmsapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import java.util.List;

public class ManageBorrowActivity extends AppCompatActivity {

    private static final String TAG = "ManageBorrowActivity";
    private RecyclerView recyclerViewBorrowed;
    private DatabaseHelper dbHelper;
    private BorrowedBooksAdapter borrowedBooksAdapter;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manage_borrow);

        // Set up window insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();
        setupToolbar();
        dbHelper = new DatabaseHelper(this);
        setupRecyclerView();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        recyclerViewBorrowed = findViewById(R.id.recyclerViewBorrowed);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupRecyclerView() {
        recyclerViewBorrowed.setLayoutManager(new LinearLayoutManager(this));

        List<BorrowedBook> borrowedBooks = dbHelper.getAllBorrowedBooks();
        borrowedBooksAdapter = new BorrowedBooksAdapter(borrowedBooks, this::editBorrowedBook, this::returnBorrowedBook);

        recyclerViewBorrowed.setAdapter(borrowedBooksAdapter);
        Log.d(TAG, "RecyclerView set up with " + borrowedBooks.size() + " borrowed books");
    }

    private void editBorrowedBook(BorrowedBook book, View view) {
      Log.d(TAG, "Edit clicked for book with ID: " + book.getId());
    }

    private void returnBorrowedBook(BorrowedBook book, View view) {
        Log.d(TAG, "Attempting to return book with ID: " + book.getId());
        boolean result = dbHelper.deleteBorrowedBook(book.getId());
        if (result) {
            borrowedBooksAdapter.removeBook(book);
            Toast.makeText(this, "Book returned successfully", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Book returned successfully with ID: " + book.getId());
        } else {
            Toast.makeText(this, "Failed to return book", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Failed to return book with ID: " + book.getId());
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}