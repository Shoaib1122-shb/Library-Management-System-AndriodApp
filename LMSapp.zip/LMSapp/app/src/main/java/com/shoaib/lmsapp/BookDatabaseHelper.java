package com.shoaib.lmsapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class BookDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BookLibrary.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TAG = "BookDatabaseHelper";

    // Table names
    private static final String TABLE_BOOKS = "books";
    private static final String TABLE_BORROWERS = "borrowers";
    private static final String TABLE_BORROW_TRANSACTIONS = "borrow_transactions";
    private static final String TABLE_RESERVATIONS = "reservations";
    private static final String TABLE_FINES = "fines";

    // Books Table Columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_ISBN = "isbn";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_AUTHOR = "author";
    private static final String COLUMN_TOTAL_NUMBER = "total_number";
    private static final String COLUMN_BORROWER_NUMBER = "borrower_number";

    // Borrowers Table Columns
    private static final String COLUMN_BORROWER_ID = "borrower_id";
    private static final String COLUMN_BORROWER_NAME = "borrower_name";
    private static final String COLUMN_BORROWER_EMAIL = "borrower_email";

    // Borrow Transactions Table Columns
    private static final String COLUMN_TRANSACTION_ID = "transaction_id";
    private static final String COLUMN_BOOK_ISBN = "book_isbn";
    private static final String COLUMN_BORROWER_ID_FK = "borrower_id";
    private static final String COLUMN_BORROW_DATE = "borrow_date";
    private static final String COLUMN_DUE_DATE = "due_date";
    private static final String COLUMN_RETURN_DATE = "return_date";

    // Reservations Table Columns
    private static final String COLUMN_RESERVATION_ID = "reservation_id";
    private static final String COLUMN_RESERVATION_BOOK_ISBN = "book_isbn";
    private static final String COLUMN_RESERVATION_BORROWER_ID = "borrower_id";
    private static final String COLUMN_RESERVATION_DATE = "reservation_date";
    private static final String COLUMN_RESERVATION_STATUS = "status";

    // Fines Table Columns
    private static final String COLUMN_FINE_ID = "fine_id";
    private static final String COLUMN_FINE_BORROWER_ID = "borrower_id";
    private static final String COLUMN_FINE_AMOUNT = "amount";
    private static final String COLUMN_FINE_PAID = "paid";

    // Create table queries
    private static final String CREATE_BOOKS_TABLE = "CREATE TABLE " + TABLE_BOOKS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_ISBN + " TEXT UNIQUE, "
            + COLUMN_NAME + " TEXT, "
            + COLUMN_AUTHOR + " TEXT, "
            + COLUMN_TOTAL_NUMBER + " INTEGER, "
            + COLUMN_BORROWER_NUMBER + " INTEGER)";

    private static final String CREATE_BORROWERS_TABLE = "CREATE TABLE " + TABLE_BORROWERS + "("
            + COLUMN_BORROWER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_BORROWER_NAME + " TEXT NOT NULL, "
            + COLUMN_BORROWER_EMAIL + " TEXT NOT NULL UNIQUE)";

    private static final String CREATE_BORROW_TRANSACTIONS_TABLE = "CREATE TABLE " + TABLE_BORROW_TRANSACTIONS + "("
            + COLUMN_TRANSACTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_BOOK_ISBN + " TEXT NOT NULL, "
            + COLUMN_BORROWER_ID_FK + " INTEGER NOT NULL, "
            + COLUMN_BORROW_DATE + " INTEGER NOT NULL, "
            + COLUMN_DUE_DATE + " INTEGER NOT NULL, "
            + COLUMN_RETURN_DATE + " INTEGER, "
            + "FOREIGN KEY (" + COLUMN_BOOK_ISBN + ") REFERENCES " + TABLE_BOOKS + "(" + COLUMN_ISBN + "), "
            + "FOREIGN KEY (" + COLUMN_BORROWER_ID_FK + ") REFERENCES " + TABLE_BORROWERS + "(" + COLUMN_BORROWER_ID + "))";

    private static final String CREATE_RESERVATIONS_TABLE = "CREATE TABLE " + TABLE_RESERVATIONS + "("
            + COLUMN_RESERVATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_RESERVATION_BOOK_ISBN + " TEXT NOT NULL, "
            + COLUMN_RESERVATION_BORROWER_ID + " INTEGER NOT NULL, "
            + COLUMN_RESERVATION_DATE + " INTEGER NOT NULL, "
            + COLUMN_RESERVATION_STATUS + " TEXT NOT NULL, "
            + "FOREIGN KEY (" + COLUMN_RESERVATION_BOOK_ISBN + ") REFERENCES " + TABLE_BOOKS + "(" + COLUMN_ISBN + "), "
            + "FOREIGN KEY (" + COLUMN_RESERVATION_BORROWER_ID + ") REFERENCES " + TABLE_BORROWERS + "(" + COLUMN_BORROWER_ID + "))";

    private static final String CREATE_FINES_TABLE = "CREATE TABLE " + TABLE_FINES + "("
            + COLUMN_FINE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_FINE_BORROWER_ID + " INTEGER NOT NULL, "
            + COLUMN_FINE_AMOUNT + " REAL NOT NULL, "
            + COLUMN_FINE_PAID + " INTEGER NOT NULL DEFAULT 0, "
            + "FOREIGN KEY (" + COLUMN_FINE_BORROWER_ID + ") REFERENCES " + TABLE_BORROWERS + "(" + COLUMN_BORROWER_ID + "))";

    public BookDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_BOOKS_TABLE);
        db.execSQL(CREATE_BORROWERS_TABLE);
        db.execSQL(CREATE_BORROW_TRANSACTIONS_TABLE);
        db.execSQL(CREATE_RESERVATIONS_TABLE);
        db.execSQL(CREATE_FINES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FINES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RESERVATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BORROW_TRANSACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BORROWERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        onCreate(db);
    }

    // Book Methods
    public long addBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_ISBN, book.getIsbn());
            values.put(COLUMN_NAME, book.getName());
            values.put(COLUMN_AUTHOR, book.getAuthor());
            values.put(COLUMN_TOTAL_NUMBER, book.getTotalNumber());
            values.put(COLUMN_BORROWER_NUMBER, book.getBorrowerNumber());
            return db.insert(TABLE_BOOKS, null, values);
        } finally {
            db.close();
        }
    }

    public Book getBook(String isbn) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_BOOKS, new String[]{
                    COLUMN_ID, COLUMN_ISBN, COLUMN_NAME, COLUMN_AUTHOR,
                    COLUMN_TOTAL_NUMBER, COLUMN_BORROWER_NUMBER
            }, COLUMN_ISBN + "=?", new String[]{isbn}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                Book book = new Book(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISBN)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_NUMBER)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_BORROWER_NUMBER))
                );
                return book;
            }
            return null;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }

    public List<Book> getAllBooks() {
        List<Book> bookList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_BOOKS, null, null, null, null, null, null);
            if (cursor.moveToFirst()) {
                do {
                    Book book = new Book(
                            cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISBN)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)),
                            cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_NUMBER)),
                            cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_BORROWER_NUMBER))
                    );
                    bookList.add(book);
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return bookList;
    }

    public int updateBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_NAME, book.getName());
            values.put(COLUMN_AUTHOR, book.getAuthor());
            values.put(COLUMN_TOTAL_NUMBER, book.getTotalNumber());
            values.put(COLUMN_BORROWER_NUMBER, book.getBorrowerNumber());
            return db.update(TABLE_BOOKS, values, COLUMN_ISBN + "=?", new String[]{book.getIsbn()});
        } finally {
            db.close();
        }
    }

    public void deleteBook(String isbn) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            db.delete(TABLE_BOOKS, COLUMN_ISBN + " = ?", new String[]{isbn});
        } finally {
            db.close();
        }
    }

    public int getBooksCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_BOOKS, null);
            return cursor.getCount();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }

    // Borrower Methods
    public long addBorrower(String name, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_BORROWER_NAME, name);
            values.put(COLUMN_BORROWER_EMAIL, email);
            return db.insert(TABLE_BORROWERS, null, values);
        } finally {
            db.close();
        }
    }

    public String getBorrowerName(int borrowerId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_BORROWERS, new String[]{COLUMN_BORROWER_NAME},
                    COLUMN_BORROWER_ID + "=?", new String[]{String.valueOf(borrowerId)},
                    null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BORROWER_NAME));
            }
            return "User";
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }




    // Fine Methods
    public long addFine(int borrowerId, double amount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put(COLUMN_FINE_BORROWER_ID, borrowerId);
            values.put(COLUMN_FINE_AMOUNT, amount);
            values.put(COLUMN_FINE_PAID, 0);
            return db.insert(TABLE_FINES, null, values);
        } finally {
            db.close();
        }
    }

    public double getTotalFines(int borrowerId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(
                    "SELECT SUM(" + COLUMN_FINE_AMOUNT + ") FROM " + TABLE_FINES +
                            " WHERE " + COLUMN_FINE_BORROWER_ID + " = ? AND " + COLUMN_FINE_PAID + " = 0",
                    new String[]{String.valueOf(borrowerId)});

            double totalFines = 0.0;
            if (cursor.moveToFirst() && !cursor.isNull(0)) {
                totalFines = cursor.getDouble(0);
            }
            return totalFines;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }

    public int getOverdueBooksCount(int borrowerId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(
                    "SELECT COUNT(*) FROM " + TABLE_BORROW_TRANSACTIONS +
                            " WHERE " + COLUMN_BORROWER_ID_FK + " = ? AND " + COLUMN_RETURN_DATE +
                            " IS NULL AND " + COLUMN_DUE_DATE + " < ?",
                    new String[]{String.valueOf(borrowerId), String.valueOf(System.currentTimeMillis())});

            int count = 0;
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            return count;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }
}