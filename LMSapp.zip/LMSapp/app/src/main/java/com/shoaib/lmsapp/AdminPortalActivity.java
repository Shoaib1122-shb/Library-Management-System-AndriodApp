package com.shoaib.lmsapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.shoaib.lmsapp.databinding.ActivityAdminPortalBinding;

public class AdminPortalActivity extends AppCompatActivity {

    private static final String TAG = "AdminPortalActivity";
    private ActivityAdminPortalBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {

            binding = ActivityAdminPortalBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            setSupportActionBar(binding.materialToolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle("Welcome Admin");
            }

            binding.adminNameText.setText("Admin: Shoaib");

            // Handle logout button click
            binding.logoutButton.setOnClickListener(v -> {
                Log.d(TAG, "Logout button clicked");
                Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
                // Redirect to MainActivity
                Intent intent = new Intent(AdminPortalActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            });

            // Handle Manage Books card click
            binding.manageBooksCard.setOnClickListener(v -> {
                Log.d(TAG, "Manage Books card clicked");
                try {
                    Intent intent = new Intent(AdminPortalActivity.this, BooksActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting BooksActivity", e);
                    Toast.makeText(this, "Error navigating to Books", Toast.LENGTH_SHORT).show();
                }
            });

            // Handle Manage Borrowers card click
            binding.manageBorrowersCard.setOnClickListener(v -> {
                Log.d(TAG, "Manage Borrowers card clicked");
                try {
                    Intent intent = new Intent(AdminPortalActivity.this, BorrowersActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting BorrowersActivity", e);
                    Toast.makeText(this, "Error navigating to Borrowers", Toast.LENGTH_SHORT).show();
                }
            });

            // Handle Manage Librarians card click
            binding.manageLibrariansCard.setOnClickListener(v -> {
                Log.d(TAG, "Manage Librarians card clicked");
                try {
                    Intent intent = new Intent(AdminPortalActivity.this, LibrarianActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting LibrarianActivity", e);
                    Toast.makeText(this, "Error navigating to Librarians", Toast.LENGTH_SHORT).show();
                }
            });

            // Handle Manage Reservations card click
            binding.manageReservationsCard.setOnClickListener(v -> {
                Log.d(TAG, "Manage Reservations card clicked");
                try {
                    Intent intent = new Intent(AdminPortalActivity.this, ManageReservationsActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting ReservationsActivity", e);
                    Toast.makeText(this, "Error navigating to Reservations", Toast.LENGTH_SHORT).show();
                }
            });

            // Handle Manage Borrow card click (new addition)
            binding.manageBorrowCard.setOnClickListener(v -> {
                Log.d(TAG, "Manage Borrow card clicked");
                try {
                    Intent intent = new Intent(AdminPortalActivity.this, ManageBorrowActivity.class);
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e(TAG, "Error starting BorrowActivity", e);
                    Toast.makeText(this, "Error navigating to Borrow", Toast.LENGTH_SHORT).show();
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "Error initializing View Binding", e);
            Toast.makeText(this, "Error loading admin portal", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}