package com.shoaib.lmsapp;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MyBorrowedBooksActivity extends AppCompatActivity {

    private static final String TAG = "MyBorrowedBooksActivity";
    private TextInputEditText etBorrowerId, etIsbn, etTitle, etAuthor, etBorrowerDate, etDueDate;
    private TextInputLayout borrowerIdContainer, isbnContainer, titleContainer, authorContainer, borrowDateContainer, dueDateContainer;
    private MaterialButton btnBorrower, btnReservation;
    private MaterialToolbar toolbar;
    private DatabaseHelper dbHelper;
    private BorrowedBook currentEditingBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_borrowed_books);

        initializeViews();
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        dbHelper = new DatabaseHelper(this);
        setupDatePickers();
        setupButtonListeners();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        etBorrowerId = findViewById(R.id.etBorrowerId);
        etIsbn = findViewById(R.id.etIsbn);
        etTitle = findViewById(R.id.etTitle);
        etAuthor = findViewById(R.id.etAuthor);
        etBorrowerDate = findViewById(R.id.etBorrowerDate);
        etDueDate = findViewById(R.id.etDueDate);

        borrowerIdContainer = findViewById(R.id.borrowerIdContainer);
        isbnContainer = findViewById(R.id.isbnContainer);
        titleContainer = findViewById(R.id.titleContainer);
        authorContainer = findViewById(R.id.authorContainer);
        borrowDateContainer = findViewById(R.id.borrowDateContainer);
        dueDateContainer = findViewById(R.id.dueDateContainer);

        btnBorrower = findViewById(R.id.btnBorrower);
        btnReservation = findViewById(R.id.btnReservation);
    }

    private void setupDatePickers() {
        Calendar calendar = Calendar.getInstance();

        DatePickerDialog.OnDateSetListener borrowDateListener = (view, year, month, day) -> {
            calendar.set(year, month, day);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            etBorrowerDate.setText(sdf.format(calendar.getTime()));
        };

        DatePickerDialog.OnDateSetListener dueDateListener = (view, year, month, day) -> {
            calendar.set(year, month, day);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            etDueDate.setText(sdf.format(calendar.getTime()));
        };

        etBorrowerDate.setOnClickListener(v -> new DatePickerDialog(
                this,
                borrowDateListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show());

        etDueDate.setOnClickListener(v -> new DatePickerDialog(
                this,
                dueDateListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show());
    }

    private void setupButtonListeners() {
        btnBorrower.setOnClickListener(v -> {
            if (currentEditingBook != null) {
                handleUpdateBook();
            } else {
                handleBorrowBook();
            }
        });
        btnReservation.setOnClickListener(v -> handleReserveBook());
    }

    private void handleBorrowBook() {
        if (validateForm()) {
            BorrowedBook book = new BorrowedBook(
                    etBorrowerId.getText().toString(),
                    etIsbn.getText().toString(),
                    etTitle.getText().toString(),
                    etAuthor.getText().toString(),
                    etBorrowerDate.getText().toString(),
                    etDueDate.getText().toString()
            );

            long result = dbHelper.addBorrowedBook(book);
            if (result != -1) {
                clearForm();
                Toast.makeText(this, "Book borrowed successfully", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Book borrowed successfully with ID: " + result);
            } else {
                Toast.makeText(this, "Failed to borrow book", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to borrow book");
            }
        }
    }

    private void handleUpdateBook() {
        if (validateForm()) {
            BorrowedBook updatedBook = new BorrowedBook(
                    currentEditingBook.getId(),
                    etBorrowerId.getText().toString(),
                    etIsbn.getText().toString(),
                    etTitle.getText().toString(),
                    etAuthor.getText().toString(),
                    etBorrowerDate.getText().toString(),
                    etDueDate.getText().toString()
            );

            boolean result = dbHelper.updateBorrowedBook(updatedBook);
            if (result) {
                clearForm();
                currentEditingBook = null;
                btnBorrower.setText(R.string.borrow_button);
                Toast.makeText(this, "Book updated successfully", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Book updated successfully with ID: " + updatedBook.getId());
            } else {
                Toast.makeText(this, "Failed to update book", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to update book with ID: " + updatedBook.getId());
            }
        }
    }

    private void handleReserveBook() {
        if (validateForm()) {
            ReservedBook book = new ReservedBook(
                    etBorrowerId.getText().toString(),
                    etIsbn.getText().toString(),
                    etTitle.getText().toString(),
                    etAuthor.getText().toString(),
                    etBorrowerDate.getText().toString()
            );

            long result = dbHelper.addReservedBook(book);
            if (result != -1) {
                clearForm();
                Toast.makeText(this, "Book reserved successfully", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Book reserved successfully with ID: " + result);
            } else {
                Toast.makeText(this, "Failed to reserve book", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to reserve book");
            }
        }
    }

    private void editBorrowedBook(BorrowedBook book) {
        currentEditingBook = book;
        etBorrowerId.setText(book.getBorrowerId());
        etIsbn.setText(book.getIsbn());
        etTitle.setText(book.getTitle());
        etAuthor.setText(book.getAuthor());
        etBorrowerDate.setText(book.getBorrowDate());
        etDueDate.setText(book.getDueDate());
        btnBorrower.setText("Update Book");
        Log.d(TAG, "Editing book with ID: " + book.getId());
    }

    private boolean validateForm() {
        boolean isValid = true;

        if (etBorrowerId.getText().toString().trim().isEmpty()) {
            borrowerIdContainer.setError("Borrower ID is required");
            isValid = false;
        } else {
            borrowerIdContainer.setError(null);
        }

        if (etIsbn.getText().toString().trim().isEmpty()) {
            isbnContainer.setError("ISBN is required");
            isValid = false;
        } else {
            isbnContainer.setError(null);
        }

        if (etTitle.getText().toString().trim().isEmpty()) {
            titleContainer.setError("Title is required");
            isValid = false;
        } else {
            titleContainer.setError(null);
        }

        if (etAuthor.getText().toString().trim().isEmpty()) {
            authorContainer.setError("Author is required");
            isValid = false;
        } else {
            authorContainer.setError(null);
        }

        if (etBorrowerDate.getText().toString().trim().isEmpty()) {
            borrowDateContainer.setError("Borrow date is required");
            isValid = false;
        } else {
            borrowDateContainer.setError(null);
        }

        if (etDueDate.getText().toString().trim().isEmpty() && currentEditingBook == null) {
            dueDateContainer.setError("Due date is required");
            isValid = false;
        } else {
            dueDateContainer.setError(null);
        }

        return isValid;
    }

    private void clearForm() {
        etBorrowerId.setText("");
        etIsbn.setText("");
        etTitle.setText("");
        etAuthor.setText("");
        etBorrowerDate.setText("");
        etDueDate.setText("");
        currentEditingBook = null;
        btnBorrower.setText(R.string.borrow_button);
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) {
            dbHelper.close();
        }
        super.onDestroy();
    }
}
