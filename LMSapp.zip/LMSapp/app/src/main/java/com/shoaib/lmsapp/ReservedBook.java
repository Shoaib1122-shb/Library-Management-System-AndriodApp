package com.shoaib.lmsapp;

public class ReservedBook {
    private int id;
    private String borrowerId;
    private String isbn;
    private String title;
    private String author;
    private String borrowDate;

    public ReservedBook(String borrowerId, String isbn, String title, String author, String borrowDate) {
        this.borrowerId = borrowerId;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.borrowDate = borrowDate;
    }

    public ReservedBook(int id, String borrowerId, String isbn, String title, String author, String borrowDate) {
        this.id = id;
        this.borrowerId = borrowerId;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.borrowDate = borrowDate;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getBorrowerId() {
        return borrowerId;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReservedBook that = (ReservedBook) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}