package com.shoaib.lmsapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SearchBorrowersActivity extends AppCompatActivity {

    private RecyclerView recyclerViewBorrowers;
    private BorrowerAdapter borrowerAdapter;
    private List<Borrower> borrowerList;
    private BorrowerDatabaseHelper dbHelper;
    private SearchView searchView;
    private ImageButton btnBack;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_borrowers);

        // Initialize views
        Toolbar toolbar = findViewById(R.id.toolbar);
        recyclerViewBorrowers = findViewById(R.id.recyclerViewBorrowers); // Updated ID
        searchView = findViewById(R.id.searchView);
        btnBack = findViewById(R.id.btnBack);

        // Set up toolbar
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Search Borrowers");
        }

        // Initialize database helper
        dbHelper = new BorrowerDatabaseHelper(this);

        // Initialize borrower list and adapter
        borrowerList = new ArrayList<>();
        borrowerAdapter = new BorrowerAdapter(borrowerList);
        recyclerViewBorrowers.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewBorrowers.setAdapter(borrowerAdapter);

        // Load all borrowers initially
        loadBorrowers();

        // Set up back button click listener
        btnBack.setOnClickListener(v -> onBackPressed());

        // Set up search view listener
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterBorrowers(newText);
                return true;
            }
        });

        // Set item click listener for borrower selection
        borrowerAdapter.setOnItemClickListener(borrower -> {
            // Handle borrower item click (e.g., open details activity)
            // Add Intent to BorrowerDetailsActivity here if needed
        });
    }

    private void loadBorrowers() {
        // Clear existing list
        borrowerList.clear();
        // Get all borrowers from database
        borrowerList.addAll(dbHelper.getAllBorrowers());
        // Notify adapter of data change
        borrowerAdapter.notifyDataSetChanged();
    }

    private void filterBorrowers(String query) {
        List<Borrower> filteredList = new ArrayList<>();
        String lowerCaseQuery = query.toLowerCase();

        // Filter borrowers based on name or user ID
        for (Borrower borrower : dbHelper.getAllBorrowers()) {
            if (borrower.getName().toLowerCase().contains(lowerCaseQuery) ||
                    borrower.getUserId().toLowerCase().contains(lowerCaseQuery)) {
                filteredList.add(borrower);
            }
        }

        // Update adapter with filtered list
        borrowerList.clear();
        borrowerList.addAll(filteredList);
        borrowerAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close database connection
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}