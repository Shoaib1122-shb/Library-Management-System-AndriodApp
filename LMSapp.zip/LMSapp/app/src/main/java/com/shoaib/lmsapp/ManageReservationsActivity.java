package com.shoaib.lmsapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import java.util.List;

public class ManageReservationsActivity extends AppCompatActivity {

    private static final String TAG = "ManageReservationsActivity";
    private RecyclerView recyclerViewReserved;
    private DatabaseHelper dbHelper;
    private ReservedBooksAdapter reservedBooksAdapter;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manage_reservations);

        // Set up window insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            return insets;
        });

        initializeViews();
        setupToolbar();
        dbHelper = new DatabaseHelper(this);
        setupRecyclerView();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        recyclerViewReserved = findViewById(R.id.recyclerViewReserved);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setupRecyclerView() {
        recyclerViewReserved.setLayoutManager(new LinearLayoutManager(this));

        List<ReservedBook> reservedBooks = dbHelper.getAllReservedBooks();
        reservedBooksAdapter = new ReservedBooksAdapter(reservedBooks, this::cancelReservedBook);

        recyclerViewReserved.setAdapter(reservedBooksAdapter);
        Log.d(TAG, "RecyclerView set up with " + reservedBooks.size() + " reserved books");
    }

    private void cancelReservedBook(ReservedBook book, View view) {
        Log.d(TAG, "Attempting to cancel reserved book with ID: " + book.getId());
        boolean result = dbHelper.deleteReservedBook(book.getId());
        if (result) {
            reservedBooksAdapter.removeBook(book);
            Toast.makeText(this, "Reservation canceled successfully", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "Reservation canceled successfully with ID: " + book.getId());
        } else {
            Toast.makeText(this, "Failed to cancel reservation", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Failed to cancel reservation with ID: " + book.getId());
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}