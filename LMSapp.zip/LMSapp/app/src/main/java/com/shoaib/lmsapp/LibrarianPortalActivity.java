 package com.shoaib.lmsapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

public class LibrarianPortalActivity extends AppCompatActivity {

    private TextView librarianNameText;
    private LibrarianDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian_portal);

        // Initialize database helper
        dbHelper = new LibrarianDatabaseHelper(this);

        // Initialize views
        librarianNameText = findViewById(R.id.librarianNameText);
        ImageButton logoutButton = findViewById(R.id.logoutButton);
        MaterialCardView manageBooksCard = findViewById(R.id.manageBooksCard);
        MaterialCardView manageBorrowersCard = findViewById(R.id.manageBorrowersCard);
        MaterialCardView manageReservationsCard = findViewById(R.id.manageReservationsCard);
        MaterialCardView manageBorrowCard = findViewById(R.id.manageBorrowCard);
        ImageButton addNewBookButton = findViewById(R.id.addNewBookButton);
        ImageButton addNewBorrowerButton = findViewById(R.id.addNewBorrowerButton);
        ImageButton borrowedButton = findViewById(R.id.borrowedButton);
        ImageButton issueBookButton = findViewById(R.id.issueBookButton);
        ImageButton searchBookButton = findViewById(R.id.searchBookButton);
        ImageButton searchBorrowerButton = findViewById(R.id.searchBorrowerButton);

        // Get staff ID from intent
        String staffId = getIntent().getStringExtra("staff_id");
        if (staffId != null) {
            // Fetch and display librarian's name
            Librarian librarian = dbHelper.getLibrarianByStaffId(staffId);
            if (librarian != null) {
                librarianNameText.setText("Welcome, " + librarian.getName());
            } else {
                librarianNameText.setText("Welcome, Librarian");
            }
        }

        // Set click listeners
        logoutButton.setOnClickListener(v -> logout());
        manageBooksCard.setOnClickListener(v -> startActivity(new Intent(this, BooksActivity.class)));
        manageBorrowersCard.setOnClickListener(v -> startActivity(new Intent(this, BorrowersActivity.class)));
        manageReservationsCard.setOnClickListener(v -> startActivity(new Intent(this, ManageReservationsActivity.class)));
        manageBorrowCard.setOnClickListener(v -> startActivity(new Intent(this, ManageBorrowActivity.class)));
        addNewBookButton.setOnClickListener(v -> startActivity(new Intent(this, BooksActivity.class)));
        addNewBorrowerButton.setOnClickListener(v -> startActivity(new Intent(this, BorrowersActivity.class)));
        borrowedButton.setOnClickListener(v -> startActivity(new Intent(this, ManageBorrowActivity.class))); // Assuming borrowed navigates to ManageBorrowActivity
        //issueBookButton.setOnClickListener(v -> startActivity(new Intent(this, IssueBookActivity.class))); // Assuming a new activity for issuing books
        searchBookButton.setOnClickListener(v -> startActivity(new Intent(this, ViewBooksActivity.class))); // New activity for searching books
        searchBorrowerButton.setOnClickListener(v -> startActivity(new Intent(this, SearchBorrowersActivity.class))); // New activity for searching borrowers

        // Apply scale animations to cards and buttons
        applyScaleAnimation(manageBooksCard, manageBorrowersCard, manageReservationsCard, manageBorrowCard,
                logoutButton, addNewBookButton, addNewBorrowerButton, borrowedButton, issueBookButton,
                searchBookButton, searchBorrowerButton);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void applyScaleAnimation(View... views) {
        for (View view : views) {
            view.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Animation animation = AnimationUtils.loadAnimation(this, R.anim.scale_on_click);
                        v.startAnimation(animation);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.clearAnimation();
                        break;
                }
                return false;
            });
        }
    }

    private void logout() {
        SharedPreferences prefs = getSharedPreferences("LibraryPrefs", MODE_PRIVATE);
        prefs.edit().clear().apply();
        startActivity(new Intent(this, LibrarianLoginActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
