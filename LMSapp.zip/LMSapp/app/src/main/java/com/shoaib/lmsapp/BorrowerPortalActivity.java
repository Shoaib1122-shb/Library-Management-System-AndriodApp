package com.shoaib.lmsapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.card.MaterialCardView;

public class BorrowerPortalActivity extends AppCompatActivity {

    private TextView borrowerNameText;
    private ImageButton logoutButton, searchBooksButton, requestBookButton;
    private MaterialCardView viewBooksCard, myBorrowedBooksCard, myProfileCard;
    private MaterialToolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrower_portal);

        // Initialize views
        initializeViews();

        // Set up toolbar
        setupToolbar();

        // Set welcome message with the user's name
        setWelcomeMessage();

        // Set click listeners
        setClickListeners();
    }

    private void initializeViews() {
        try {
            toolbar = findViewById(R.id.material_toolbar);
            borrowerNameText = findViewById(R.id.borrowerNameText);
            logoutButton = findViewById(R.id.logoutButton);
            viewBooksCard = findViewById(R.id.viewBooksCard);
            myBorrowedBooksCard = findViewById(R.id.myBorrowedBooksCard);
            myProfileCard = findViewById(R.id.myProfileCard);
            searchBooksButton = findViewById(R.id.searchBooksButton);
            requestBookButton = findViewById(R.id.requestBookButton);
        } catch (Exception e) {
            // Handle initialization errors (e.g., view not found)
            e.printStackTrace();
            finish(); // Close activity if critical views are missing
        }
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
    }

    private void setWelcomeMessage() {
        // Replace with actual user name from authentication system if available
        String username = getIntent().getStringExtra("username") != null
                ? getIntent().getStringExtra("username") : "To LMS ! Enjoying Book Reading";
        borrowerNameText.setText(String.format("Welcome %s", username));
    }

    private void setClickListeners() {
        // Logout button
        logoutButton.setOnClickListener(v -> logoutUser());

        // Main action cards
        viewBooksCard.setOnClickListener(v -> openViewBooks());
        myBorrowedBooksCard.setOnClickListener(v -> openBorrowedBooks());
        myProfileCard.setOnClickListener(v -> openProfile());

        // Quick action buttons
        searchBooksButton.setOnClickListener(v -> searchBooks());
        requestBookButton.setOnClickListener(v -> requestBook());
    }

    private void logoutUser() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        finish();
    }

    private void openViewBooks() {
        startActivityWithTransition(new Intent(this, ViewBooksActivity.class));
    }

    private void openBorrowedBooks() {
        startActivityWithTransition(new Intent(this, MyBorrowedBooksActivity.class));
    }

    private void openProfile() {
        startActivityWithTransition(new Intent(this, MyProfileActivity.class));
    }

    private void searchBooks() {
        startActivityWithTransition(new Intent(this, ViewBooksActivity.class));
    }

    private void requestBook() {
        startActivityWithTransition(new Intent(this, MyBorrowedBooksActivity.class));
    }

    private void startActivityWithTransition(Intent intent) {
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    /*
    // Uncomment if menu is needed
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.borrower_dashboard_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            // Handle settings action
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    */
}