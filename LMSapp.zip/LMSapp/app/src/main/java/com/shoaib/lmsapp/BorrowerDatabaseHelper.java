package com.shoaib.lmsapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class BorrowerDatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "LibraryManagementSystem.db";

    // Table name
    private static final String TABLE_BORROWERS = "borrowers";

    // Table Columns
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_ADDRESS = "address";
    private static final String COLUMN_CITY = "city";
    private static final String COLUMN_STATE = "state";
    private static final String COLUMN_ZIP_CODE = "zip_code";
    private static final String COLUMN_PASSWORD = "password";

    // Create Table Query
    private static final String CREATE_TABLE_BORROWERS = "CREATE TABLE " + TABLE_BORROWERS + "("
            + COLUMN_USER_ID + " TEXT PRIMARY KEY,"
            + COLUMN_NAME + " TEXT,"
            + COLUMN_ADDRESS + " TEXT,"
            + COLUMN_CITY + " TEXT,"
            + COLUMN_STATE + " TEXT,"
            + COLUMN_ZIP_CODE + " TEXT,"
            + COLUMN_PASSWORD + " TEXT"
            + ")";

    public BorrowerDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create tables
        db.execSQL(CREATE_TABLE_BORROWERS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BORROWERS);

        // Create tables again
        onCreate(db);
    }

    // CRUD Operations

    // Add new Borrower
    public long addBorrower(Borrower borrower) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, borrower.getUserId());
        values.put(COLUMN_NAME, borrower.getName());
        values.put(COLUMN_ADDRESS, borrower.getAddress());
        values.put(COLUMN_CITY, borrower.getCity());
        values.put(COLUMN_STATE, borrower.getState());
        values.put(COLUMN_ZIP_CODE, borrower.getZipCode());
        values.put(COLUMN_PASSWORD, borrower.getPassword());

        // Insert row
        long id = db.insert(TABLE_BORROWERS, null, values);

        // Close db connection
        db.close();

        return id;
    }

    // Get single Borrower
    public Borrower getBorrower(String userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_BORROWERS,
                new String[] { COLUMN_USER_ID, COLUMN_NAME, COLUMN_ADDRESS, COLUMN_CITY, COLUMN_STATE, COLUMN_ZIP_CODE, COLUMN_PASSWORD },
                COLUMN_USER_ID + "=?",
                new String[] { userId },
                null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            Borrower borrower = new Borrower(
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDRESS)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CITY)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ZIP_CODE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD))
            );

            cursor.close();
            return borrower;
        }

        if (cursor != null) {
            cursor.close();
        }

        return null;
    }

    // Get all Borrowers
    public List<Borrower> getAllBorrowers() {
        List<Borrower> borrowerList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_BORROWERS + " ORDER BY " + COLUMN_NAME + " ASC";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // Loop through all rows and add to list
        if (cursor.moveToFirst()) {
            do {
                Borrower borrower = new Borrower();
                borrower.setUserId(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_ID)));
                borrower.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)));
                borrower.setAddress(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDRESS)));
                borrower.setCity(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CITY)));
                borrower.setState(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATE)));
                borrower.setZipCode(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ZIP_CODE)));
                borrower.setPassword(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD)));

                // Add to list
                borrowerList.add(borrower);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return borrowerList;
    }

    // Update Borrower
    public int updateBorrower(Borrower borrower) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, borrower.getName());
        values.put(COLUMN_ADDRESS, borrower.getAddress());
        values.put(COLUMN_CITY, borrower.getCity());
        values.put(COLUMN_STATE, borrower.getState());
        values.put(COLUMN_ZIP_CODE, borrower.getZipCode());
        values.put(COLUMN_PASSWORD, borrower.getPassword());

        // Update row
        int result = db.update(TABLE_BORROWERS, values, COLUMN_USER_ID + " = ?",
                new String[] { borrower.getUserId() });

        db.close();

        return result;
    }

    // Delete Borrower
    public int deleteBorrower(String userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Delete row
        int result = db.delete(TABLE_BORROWERS, COLUMN_USER_ID + " = ?",
                new String[] { userId });

        db.close();

        return result;
    }

    // Get Borrowers count
    public int getBorrowersCount() {
        String countQuery = "SELECT * FROM " + TABLE_BORROWERS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        int count = cursor.getCount();
        cursor.close();

        return count;
    }
}