package com.shoaib.lmsapp;

public class Book {
    private int id;
    private String isbn;
    private String name;
    private String author;
    private int totalNumber;
    private int borrowerNumber;

    // Default constructor
    public Book() {
    }

    // Constructor with all fields
    public Book(int id, String isbn, String name, String author, int totalNumber, int borrowerNumber) {
        this.id = id;
        this.isbn = isbn;
        this.name = name;
        this.author = author;
        this.totalNumber = totalNumber;
        this.borrowerNumber = borrowerNumber;
    }

    // Constructor without id (for adding new books)
    public Book(String isbn, String name, String author, int totalNumber, int borrowerNumber) {
        this.isbn = isbn;
        this.name = name;
        this.author = author;
        this.totalNumber = totalNumber;
        this.borrowerNumber = borrowerNumber;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getTotalNumber() {
        return totalNumber;
    }

    public void setTotalNumber(int totalNumber) {
        this.totalNumber = totalNumber;
    }

    public int getBorrowerNumber() {
        return borrowerNumber;
    }

    public void setBorrowerNumber(int borrowerNumber) {
        this.borrowerNumber = borrowerNumber;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", isbn='" + isbn + '\'' +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", totalNumber=" + totalNumber +
                ", borrowerNumber=" + borrowerNumber +
                '}';
    }
}